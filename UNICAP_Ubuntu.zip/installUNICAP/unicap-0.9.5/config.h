/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.in by autoheader.  */

/* Define to build dcam cpi */
#define BUILD_DCAM 1

/* Define to build v4l cpi */
#define BUILD_V4L 1

/* Define to build v4l2 cpi */
#define BUILD_V4L2 1

/* Define to build vid21394 cpi */
#define BUILD_VID21394 1

/* Define to enable debug output */
#define DCAM_DEBUG 0

/* Define to 1 if translation of program messages to the user's native
   language is requested. */
#define ENABLE_NLS 1

/* Define to enable static cpi */
/* #undef ENABLE_STATIC_CPI */

/* Gettext Package */
#define GETTEXT_PACKAGE "unicap"

/* Define to use alsa sound support */
#define HAVE_ALSA 1

/* Define to use avcodec */
#define HAVE_AVCODEC 0

/* Define to 1 if you have the MacOS X function CFLocaleCopyCurrent in the
   CoreFoundation framework. */
/* #undef HAVE_CFLOCALECOPYCURRENT */

/* Define to 1 if you have the MacOS X function CFPreferencesCopyAppValue in
   the CoreFoundation framework. */
/* #undef HAVE_CFPREFERENCESCOPYAPPVALUE */

/* Define if the GNU dcgettext() function is already present or preinstalled.
   */
#define HAVE_DCGETTEXT 1

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* Define if the GNU gettext() function is already present or preinstalled. */
#define HAVE_GETTEXT 1

/* Define if you have the iconv() function. */
/* #undef HAVE_ICONV */

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define if DL lib is present */
#define HAVE_LIBDL 1

/* Define if libm is present */
#define HAVE_LIBM 1

/* Define if libpthread is present */
#define HAVE_LIBPTHREAD 1

/* Define if librt is present */
#define HAVE_LIBRT 1

/* Define if XVideo lib is present */
/* #undef HAVE_LIBXV */

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* Define to compile in PNG support */
#define HAVE_PNG 0

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to use theora video support */
#define HAVE_THEORA 0

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to the sub-directory in which libtool stores uninstalled libraries.
   */
#define LT_OBJDIR ".libs/"

/* Name of package */
#define PACKAGE "unicap"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "arne@unicap-imaging.org"

/* Define to the full name of this package. */
#define PACKAGE_NAME "unicap"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "unicap 1.0"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "unicap"

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.0"

/* Define if using the old raw1394 API */
/* #undef RAW1394_1_0_API */

/* Define if using the new raw1394 API */
#define RAW1394_1_1_API 1

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* Define to enable debug output */
#define THING_DEBUG 0

/* Define to enable debug output */
#define UCIL_DEBUG 0

/* Define to enable debug output */
#define UNICAPGTK_DEBUG 0

/* Define to enable debug output */
#define UNICAP_DEBUG 0

/* Define to enable threads */
#define UNICAP_THREADS 1

/* Define to enable thread locking */
#define UNICAP_THREAD_LOCKING 1

/* Define to enable libv4l support */
/* #undef USE_LIBV4L */

/* Define to enable debug output */
#define V4L2_DEBUG 0

/* Define to enable debug output */
#define V4L_DEBUG 0

/* Version number of package */
#define VERSION "0.9.5"

/* Define to enable bootload support */
#define VID21394_BOOTLOAD 0

/* Define to enable debug output */
#define VID21394_DEBUG 0

/* Define to enable autodetection of DFK 21CF04 camera module */
#define VID21394_DETECT_21CF04 1

/* Define to enable vid21394 visca support */
#define VID21394_VISCA 0

/* Define to 1 if the X Window System is missing or not being used. */
/* #undef X_DISPLAY_MISSING */
